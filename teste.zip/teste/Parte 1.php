<?php
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $codigo = $_POST['codigo'];
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $valor = $_POST['valor'] ?: 0.00;
    $quantidade = $_POST['quantidade'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("SELECT * FROM produtos WHERE codigo = ?");
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $error = "Código do produto já está em uso.";
    } else {
        $stmt = $conn->prepare("INSERT INTO produtos (codigo, nome, descricao, valor, quantidade, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssds", $codigo, $nome, $descricao, $valor, $quantidade, $status);
        if ($stmt->execute()) {
            header("Location: listagem.php");
            exit;
        } else {
            $error = "Erro ao cadastrar produto.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Produto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Cadastrar Produto</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="codigo" class="form-label">Código</label>
                <input type="text" class="form-control" id="codigo" name="codigo" required>
            </div>
           
::contentReference[oaicite:7]{index=7}